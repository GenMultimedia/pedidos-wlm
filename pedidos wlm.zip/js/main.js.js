import { db } from './firebase.js';
import { doc, getDoc } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";

async function cargarDatosSitio() {
    try {
        const docRef = doc(db, "sitio", "datos");
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
            const datos = docSnap.data();
            // Actualizar el contenido del sitio con los datos cargados
            document.getElementById('titulo').textContent = datos.textos.find(t => t.id === 'titulo').texto;
            document.getElementById('subtitulo').textContent = datos.textos.find(t => t.id === 'subtitulo').texto;
            // ... actualizar más elementos según sea necesario
        }
    } catch (error) {
        console.error("Error al cargar los datos del sitio:", error);
    }
}

document.addEventListener('DOMContentLoaded', cargarDatosSitio);